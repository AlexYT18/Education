#include "threads/synch.h"
#include "threads/thread.h"
#include "devices/timer.h"
#include <stdio.h>

enum carDirection { dir_left, dir_right };
enum carPriority { car_normal, car_emergency };
static struct semaphore norm_left_t, norm_right_q, accue_left_u, accue_right_d;
static int count_car_on;
static enum carDirection currDirr;
static int wait_tres, wait_quatro, wait_uno, wait_dos;

void narrow_bridge_init(void) 
{
    sema_init(&norm_left_t, 0);
    sema_init(&norm_right_q, 0);
    sema_init(&accue_left_u, 0);
    sema_init(&accue_right_d, 0);
    count_car_on = 0;
    wait_tres = wait_quatro = 0;
    wait_uno = wait_dos = 0;
}

static void await(enum carPriority prio, enum carDirection dir) 
{
     if  (prio == car_emergency) 
    {
         if  (dir == dir_left) wait_uno++;
        else wait_dos++;
    } else 
    {
         if  (dir == dir_left) wait_tres++;
        else wait_quatro++;
    }
     if  (prio == car_emergency) 
    {
         if  (dir == dir_left) sema_down(&accue_left_u);
        else sema_down(&accue_right_d);
    } 
    else 
    {
         if  (dir == dir_left) sema_down(&norm_left_t);
        else sema_down(&norm_right_q);
    }
    return;
}

static void relNaprov(enum carDirection dir) {
    int gone = 0, leaving = 0, i;

     if  (dir == dir_left) {
         if  (wait_uno > 0) {
             if  (wait_uno >= 2) 
             {
                leaving = 2;
            } else {
                leaving = 1;
            }
            for (i = 0; i < leaving; i++) {
                sema_up(&accue_left_u);
                wait_uno--;
                gone++;
            }
             if  (gone == 1 && wait_tres > 0) {
                sema_up(&norm_left_t);
                wait_tres--;
                gone++;
            }
        } else  if  (wait_tres > 0) {
             if  (wait_tres >= 2) {
                leaving = 2;
            } else {
                leaving = 1;
            }
            for (i = 0; i < leaving; i++) {
                sema_up(&norm_left_t);
                wait_tres--;
                gone++;
            }
        }
    } 
    else 
    {
         if  (wait_dos > 0) 
        {
             if  (wait_dos >= 2) leaving = 2;
            else leaving = 1;
            
            for (i = 0; i < leaving; i++) 
            {
                sema_up(&accue_right_d);
                wait_dos--;
                gone++;
            }
             if  (gone == 1 && wait_quatro > 0) 
            {
                sema_up(&norm_right_q);
                wait_quatro--;
                gone++;
            }
        } 
        else  if  (wait_quatro > 0) 
        {
             if  (wait_quatro >= 2) leaving = 2;
            else leaving = 1;
            for (i = 0; i < leaving; i++) 
            {
                sema_up(&norm_right_q);
                wait_quatro--;
                gone++;
            }
        }
    }
}

void arrive_bridge(enum carPriority prio, enum carDirection dir) 
{
     if  (count_car_on == 0) 
     {
        currDirr = dir;
        count_car_on++;
        return;
    }
     if  (dir != currDirr) 
     {
        await(prio, dir);
        count_car_on++;
        return;
    }
     if  (count_car_on < 2) 
     {
         if  (prio == car_normal) 
         {
             if  ((dir == dir_left && wait_uno > 0) || (dir == dir_right && wait_dos > 0)) await(prio, dir);
        }
        count_car_on++;
        return;
    }
    await(prio, dir);

    count_car_on++;
}
void navigat(enum carDirection a, int pov)
{
     if  (pov == 1)//left
    {
        currDirr = dir_left;
        relNaprov(dir_left);
    }
     if  (pov == 2)//right
    {
        currDirr = dir_right;
        relNaprov(dir_right);
    }
}
void exit_bridge(enum carPriority prio, enum carDirection dir) 
{
    count_car_on--;

     if  (count_car_on == 0) 
     {
         if  (wait_uno > 0 || wait_dos > 0) 
        {
             if  (wait_uno >= wait_dos)navigat(currDirr,1);
            else navigat(currDirr,2);
        } 
        else  if  (wait_tres > 0 || wait_quatro > 0) {
             if  ((currDirr == dir_left && wait_tres > 0) || (currDirr == dir_right && wait_quatro > 0)) relNaprov(currDirr);
            else  if  (wait_tres > 0) navigat(currDirr,1);
            else  if  (wait_quatro > 0) navigat(currDirr,2);
        }
    }
}
